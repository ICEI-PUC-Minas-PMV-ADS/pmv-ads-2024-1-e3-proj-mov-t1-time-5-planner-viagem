import React from 'react'
import {View, Text} from 'react-native'

const HomePage = () => {

  return (
    <View style={{flex:1, alignItems:'center', justifyContent:'center'}}>
      <Text>teste by isaac</Text>
    </View>
  )
}

export default HomePage;